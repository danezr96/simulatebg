export const PLAYABLE_SECTOR_CODES = ["AGRI", "AUTO"] as const;

const PLAYABLE_SECTOR_CODE_SET = new Set<string>(PLAYABLE_SECTOR_CODES);

export type PlayableSectorCode = (typeof PLAYABLE_SECTOR_CODES)[number];

export function isSectorPlayable(code?: string | null): code is PlayableSectorCode {
  return !!code && PLAYABLE_SECTOR_CODE_SET.has(code);
}
