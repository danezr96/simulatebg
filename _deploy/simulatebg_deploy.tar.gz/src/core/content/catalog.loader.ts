import type { CatalogData } from "./catalog.types";

export function loadCatalog(data?: CatalogData): CatalogData {
  const fallback: CatalogData = { sectors: [], niches: [], products: [] };
  return data ?? fallback;
}
